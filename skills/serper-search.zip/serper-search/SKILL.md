---
name: serper-search
description: |
  使用 Serper.dev Google Search API 进行网页搜索。
  **Use this skill when:**
  (1) 用户需要搜索网页信息、查找资料、了解最新动态
  (2) 用户说"搜索XXX"、"查一下XXX"、"Google一下"
  (3) 需要获取实时信息、新闻、技术文档等
  (4) web_search 工具失败或不可用时
  
  **Do NOT use when:**
  (1) 可以直接用 web_fetch 获取已知 URL 的内容
  (2) 问题可以通过已有知识直接回答
  
  **Keywords:** 搜索, 查找, Google, 查询, search, look up
---

# Serper 搜索 Skill

使用 Serper.dev 的 Google Search API 进行网页搜索。

## 前置条件

Serper API Key 已配置在：
`~/.openclaw/skills/search-layer/scripts/credentials.json`

格式：
```json
{
  "serper": "YOUR_API_KEY"
}
```

当前 API Key 已配置，可直接使用。

## 搜索方法

### 方法1：直接调用 Python 脚本

```python
import requests
import json

def search_serper(query: str, num: int = 10) -> list:
    """使用 Serper 搜索 Google"""
    url = 'https://google.serper.dev/search'
    
    # 读取 API key
    with open('~/.openclaw/skills/search-layer/scripts/credentials.json', 'r') as f:
        cred = json.load(f)
    api_key = cred['serper']
    
    headers = {
        'X-API-KEY': api_key,
        'Content-Type': 'application/json'
    }
    payload = {
        'q': query,
        'num': num
    }
    
    response = requests.post(url, headers=headers, json=payload)
    data = response.json()
    
    results = []
    for item in data.get('organic', []):
        results.append({
            'title': item.get('title'),
            'link': item.get('link'),
            'snippet': item.get('snippet'),
            'date': item.get('date')
        })
    
    return results
```

### 方法2：使用 search-layer 的 search_serper 函数

```python
import sys
sys.path.insert(0, '~/.openclaw/skills/search-layer/scripts')
from search import search_serper

results = search_serper('搜索关键词', 'API_KEY', num=5)
```

## 搜索示例

### 基本搜索

```python
results = search_serper('OpenAI GPT-5 最新进展', num=5)

# 输出格式：
# [
#   {
#     'title': 'OpenAI announces GPT-5...',
#     'link': 'https://openai.com/blog/...',
#     'snippet': 'OpenAI today announced...',
#     'date': 'Mar 21, 2026'
#   },
#   ...
# ]
```

### 中文搜索

```python
results = search_serper('贵州白酒交易所 最新动态', num=5)
```

### 技术搜索

```python
results = search_serper('Python 3.14 new features site:python.org', num=3)
```

## 输出格式

向用户展示搜索结果时：

```markdown
**搜索 "关键词" 的结果：**

1. **[标题](链接)**
   - 摘要：内容摘要...
   - 日期：2026-03-21

2. **[标题](链接)**
   - 摘要：内容摘要...

...
```

## 高级用法

### 限制搜索范围

```python
# 只搜索特定网站
results = search_serper('AI news site:techcrunch.com', num=5)

# 搜索 PDF 文件
results = search_serper('machine learning filetype:pdf', num=5)

# 精确匹配
results = search_serper('"GPT-5 release date"', num=5)
```

### 获取新闻结果

```python
# 添加时间参数获取最新新闻
results = search_serper('Google AI news today', num=10)
```

## 注意事项

1. **API 配额**：每次搜索消耗 1 个 credit
2. **速率限制**：每秒最多 10 次请求
3. **结果数量**：最多返回 100 条结果
4. **中文支持**：完全支持中文搜索

## 错误处理

```python
try:
    results = search_serper('搜索词', num=5)
    if not results:
        return "未找到相关结果，建议更换关键词试试。"
except Exception as e:
    return f"搜索出错：{e}，可以尝试使用浏览器自动化搜索作为备选。"
```

## 备选方案

如果 Serper 搜索失败：
1. 使用浏览器自动化访问 DuckDuckGo 搜索
2. 使用 web_fetch 直接获取已知 URL
3. 询问用户是否提供具体网址
