---
name: volcengine-ark-vision
description: |
  火山引擎方舟视觉分析工具。使用 Doubao-vision 模型进行图像理解和分析。
  
  支持功能：
  - 图像内容描述
  - 图像文字识别 (OCR)
  - 图像细节分析
  - 多轮对话理解图像
---

# Volcengine Ark Vision Skill

## 配置

API Key: `ab6ba08f-1954-487b-af16-2fea9a4e8aa6`
Base URL: `https://ark.cn-beijing.volces.com/api/v3`

## 使用方式

### 单张图片分析

```bash
curl https://ark.cn-beijing.volces.com/api/v3/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ab6ba08f-1954-487b-af16-2fea9a4e8aa6" \
  -d '{
    "model": "doubao-vision-pro-32k-241028",
    "max_tokens": 4096,
    "messages": [
      {
        "role": "user",
        "content": [
          {
            "type": "image_url",
            "image_url": {
              "url": "https://example.com/image.jpg"
            }
          },
          {
            "type": "text",
            "text": "请描述这张图片的内容"
          }
        ]
      }
    ]
  }'
```

### Python 调用示例

```python
import requests

def analyze_image(image_url, prompt="描述这张图片"):
    url = "https://ark.cn-beijing.volces.com/api/v3/chat/completions"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer ab6ba08f-1954-487b-af16-2fea9a4e8aa6"
    }
    data = {
        "model": "doubao-vision-pro-32k-241028",
        "max_tokens": 4096,
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image_url",
                        "image_url": {"url": image_url}
                    },
                    {
                        "type": "text",
                        "text": prompt
                    }
                ]
            }
        ]
    }
    response = requests.post(url, headers=headers, json=data)
    return response.json()["choices"][0]["message"]["content"]
```

## 支持的模型

| 模型 | 描述 |
|------|------|
| `doubao-vision-pro-32k-241028` |  Doubao 视觉专业版，32K 上下文 |
| `doubao-vision-lite-32k-241028` | Doubao 视觉轻量版 |

## 常见用法

1. **图像描述**: "描述这张图片"
2. **OCR 识别**: "提取图片中的文字"
3. **物体识别**: "图中有哪些物体？"
4. **场景分析**: "这是什么场景？"
5. **表格提取**: "将图片中的表格转为 Markdown"
