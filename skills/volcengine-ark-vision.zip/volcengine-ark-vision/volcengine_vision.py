#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
火山引擎方舟视觉分析工具
使用 Doubao-vision 模型分析图片
"""

import requests
import sys
import json
import base64

# 配置
API_KEY = "ab6ba08f-1954-487b-af16-2fea9a4e8aa6"
BASE_URL = "https://ark.cn-beijing.volces.com/api/v3/chat/completions"

# 使用 Endpoint ID（不是模型名称）
# 在方舟控制台创建推理端点后获取，格式如：ep-20250320xxxxxx-xxxxxx
MODEL = "<YOUR_ENDPOINT_ID>"  # ← 替换为你的 Endpoint ID

def analyze_image(image_source, prompt="请描述这张图片的内容"):
    """
    分析图片
    
    Args:
        image_source: 图片 URL 或本地文件路径
        prompt: 分析提示词
    
    Returns:
        分析结果文本
    """
    # 判断是 URL 还是本地文件
    if image_source.startswith(('http://', 'https://')):
        image_content = {
            "type": "image_url",
            "image_url": {"url": image_source}
        }
    else:
        # 本地文件，转为 base64
        with open(image_source, "rb") as f:
            image_data = base64.b64encode(f.read()).decode('utf-8')
        image_content = {
            "type": "image_url",
            "image_url": {"url": f"data:image/jpeg;base64,{image_data}"}
        }
    
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {API_KEY}"
    }
    
    data = {
        "model": MODEL,
        "max_tokens": 4096,
        "messages": [
            {
                "role": "user",
                "content": [
                    image_content,
                    {
                        "type": "text",
                        "text": prompt
                    }
                ]
            }
        ]
    }
    
    try:
        response = requests.post(BASE_URL, headers=headers, json=data, timeout=60)
        response.raise_for_status()
        result = response.json()
        return result["choices"][0]["message"]["content"]
    except Exception as e:
        return f"分析失败: {e}"

def main():
    if len(sys.argv) < 2:
        print("用法: python volcengine_vision.py <图片URL或路径> [提示词]")
        print("示例: python volcengine_vision.py https://example.com/image.jpg")
        print("示例: python volcengine_vision.py ./photo.jpg '提取图片中的文字'")
        sys.exit(1)
    
    image_source = sys.argv[1]
    prompt = sys.argv[2] if len(sys.argv) > 2 else "请描述这张图片的内容"
    
    print(f"[INFO] 正在分析图片: {image_source}")
    print(f"[INFO] 提示词: {prompt}\n")
    
    result = analyze_image(image_source, prompt)
    print(result)

if __name__ == '__main__':
    main()
