#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Seedream图像生成API调用脚本
支持文生图、图生图、组图、多图融合,生成后自动上传到文件服务器
"""

import os
import sys
import json
import time
import requests
import argparse

# 读取环境变量
env_file = os.path.expanduser('~/.openclaw/.env')
if os.path.exists(env_file):
    with open(env_file, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                key, value = line.split('=', 1)
                os.environ[key.strip()] = value.strip()

ARK_API_KEY = os.getenv('ARK_API_KEY')
FILE_SERVER_URL = os.getenv('FILE_SERVER_URL')
FILE_SERVER_TOKEN = os.getenv('FILE_SERVER_TOKEN')

def generate_image(prompt, model="doubao-seedream-4-5-251128", size="2K", 
                   image_url=None, image_urls=None, sequential=False, 
                   max_images=15, output_format="png", watermark=False):
    """生成图像"""
    
    if not ARK_API_KEY:
        raise ValueError("ARK_API_KEY not found in environment")
    
    # 构建请求体
    payload = {
        "model": model,
        "prompt": prompt,
        "size": size,
        "n": 1,
        "response_format": output_format,
        "watermark": watermark
    }
    
    # 添加参考图
    if image_url:
        payload["image_url"] = image_url
    elif image_urls:
        payload["image_urls"] = image_urls
    
    # 组图模式
    if sequential:
        payload["sequential"] = True
        payload["max_images"] = max_images
    
    headers = {
        "Authorization": f"Bearer {ARK_API_KEY}",
        "Content-Type": "application/json"
    }
    
    print(f"正在生成图像: {prompt[:50]}...")
    
    response = requests.post(
        "https://ark.cn-beijing.volces.com/api/v3/images/generations",
        headers=headers,
        json=payload,
        timeout=120
    )
    
    if response.status_code != 200:
        raise Exception(f"API请求失败: {response.status_code} - {response.text}")
    
    result = response.json()
    
    if "data" not in result:
        raise Exception(f"API返回异常: {result}")
    
    image_urls = [item["url"] for item in result["data"]]
    print(f"生成成功,共{len(image_urls)}张图片")
    
    return image_urls

def upload_to_file_server(image_url):
    """上传图片到文件服务器"""
    
    if not FILE_SERVER_URL or not FILE_SERVER_TOKEN:
        raise ValueError("FILE_SERVER_URL or FILE_SERVER_TOKEN not found")
    
    print(f"正在上传到文件服务器: {image_url[:50]}...")
    
    # 下载图片
    img_response = requests.get(image_url, timeout=30)
    if img_response.status_code != 200:
        raise Exception(f"下载图片失败: {img_response.status_code}")
    
    # 上传到文件服务器
    files = {'file': ('image.png', img_response.content, 'image/png')}
    headers = {'Authorization': f'Bearer {FILE_SERVER_TOKEN}'}
    
    upload_response = requests.post(
        FILE_SERVER_URL,
        files=files,
        headers=headers,
        timeout=60
    )
    
    if upload_response.status_code != 200:
        raise Exception(f"上传失败: {upload_response.status_code} - {upload_response.text}")
    
    result = upload_response.json()
    
    if result.get('code') != 200:
        raise Exception(f"上传失败: {result}")
    
    uploaded_url = result['data']['url']
    print(f"上传成功: {uploaded_url}")
    
    return uploaded_url

def generate_and_upload(prompt, **kwargs):
    """生成并上传"""
    image_urls = generate_image(prompt, **kwargs)
    uploaded_urls = []
    
    for url in image_urls:
        uploaded_url = upload_to_file_server(url)
        uploaded_urls.append(uploaded_url)
    
    return uploaded_urls

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Seedream图像生成')
    parser.add_argument('command', choices=['generate', 'generate-upload', 'upload'])
    parser.add_argument('prompt', nargs='?', help='生成提示词')
    parser.add_argument('--model', default='doubao-seedream-4-5-251128')
    parser.add_argument('--size', default='2K')
    parser.add_argument('--format', default='png')
    parser.add_argument('--image', help='单张参考图URL')
    parser.add_argument('--images', help='多张参考图URL(逗号分隔)')
    parser.add_argument('--sequential', action='store_true', help='组图模式')
    parser.add_argument('--max-images', type=int, default=15)
    parser.add_argument('--watermark', action='store_true')
    
    args = parser.parse_args()
    
    try:
        if args.command == 'generate-upload':
            kwargs = {
                'model': args.model,
                'size': args.size,
                'output_format': args.format,
                'sequential': args.sequential,
                'max_images': args.max_images,
                'watermark': args.watermark
            }
            if args.image:
                kwargs['image_url'] = args.image
            elif args.images:
                kwargs['image_urls'] = args.images.split(',')
            
            urls = generate_and_upload(args.prompt, **kwargs)
            print("\n生成的图片链接:")
            for url in urls:
                print(url)
        
        elif args.command == 'generate':
            kwargs = {
                'model': args.model,
                'size': args.size,
                'output_format': args.format,
                'sequential': args.sequential,
                'max_images': args.max_images,
                'watermark': args.watermark
            }
            if args.image:
                kwargs['image_url'] = args.image
            elif args.images:
                kwargs['image_urls'] = args.images.split(',')
            
            urls = generate_image(args.prompt, **kwargs)
            print("\n临时图片链接(24小时有效):")
            for url in urls:
                print(url)
        
        elif args.command == 'upload':
            url = upload_to_file_server(args.prompt)
            print(f"\n上传成功: {url}")
    
    except Exception as e:
        print(f"错误: {e}", file=sys.stderr)
        sys.exit(1)


