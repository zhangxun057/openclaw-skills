$chatlogsDir = "C:\Users\44452\.openclaw\chat-logs\main"
$date = "2026-04-05"

$pattern = "${date}_*.jsonl"
$files = Get-ChildItem -Path $chatlogsDir -Filter $pattern -ErrorAction SilentlyContinue

$result = @()
foreach ($file in $files) {
    $firstLine = $null
    try {
        $firstLine = Get-Content $file.FullName -First 1 | ConvertFrom-Json
    } catch {}
    
    $skip = $false
    if ($firstLine -and $firstLine.text -match '\[cron:') {
        $skip = $true
    }
    
    if (-not $skip) {
        $result += @{
            filename = $file.Name
            path = $file.FullName
            sizeKB = [math]::Round($file.Length / 1KB, 1)
            sessionId = $file.BaseName -replace "${date}_", ""
        }
    }
}

$result | ConvertTo-Json -Depth 3