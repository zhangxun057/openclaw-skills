---
name: wechat-preparer
description: |
  微信数据预处理引擎。统一处理朋友圈、私聊、群聊的 L0→L1→L2 流水线。
  由当前 Agent 模型完成结构化抽取，脚本只做数据准备和落库，不调用外部 API。
  触发词：微信数据处理、微信预处理、提取朋友圈、朋友圈数据准备、私聊提取、群聊提取、chat分析、moments prepare。
version: 4.4.0
---

# 微信数据预处理引擎

统一处理朋友圈、私聊、群聊三种数据源。脚本负责数据准备和落库，Agent 模型负责内容抽取。

**执行模式：** 默认按 朋友圈 → 私聊 → 群聊 串行处理。用户指定单一数据源时，只处理该数据源。

---

## 数据源

| 数据源 | L0 路径 | 文件格式 | 抽取方式 |
|--------|---------|---------|---------|
| 朋友圈 | `raw/moments-analysis/YYYYMMDD.json` | `{date, posts[]}` | 去重 → Agent 模型抽取 4 维度 |
| 私聊 | `raw/chat-analysis/chat_YYYYMMDDHH.jsonl` | `{sessionId, sessionName, messages[]}` | prepare_chat 切分去重 → Agent 模型抽取 |
| 群聊 | `raw/group-chat-analysis/group_chat_YYYYMMDDHH.jsonl` | `{sessionId, sessionName, messages[]}` | 过滤 → 按 session 分析 |

私聊由 `scripts/prepare_chat.py` 做新会话段准备；朋友圈由 `scripts/prepare_data.py` 做新帖准备。群聊当前由 Agent 读取原始群聊文件后过滤与抽取。

---

## 目录结构

**数据根目录：** `~/.openclaw/`

```
~/.openclaw/
├── raw/
│   ├── moments-analysis/              ← L0 朋友圈原始
│   │   └── YYYYMMDD.json
│   ├── chat-analysis/                 ← L0 私聊原始
│   │   └── chat_YYYYMMDDHH.jsonl
│   ├── group-chat-analysis/           ← L0 群聊原始
│   │   └── group_chat_YYYYMMDDHH.jsonl
│   ├── extracted_moment/              ← L1 朋友圈提取
│   │   ├── moment_extracted_YYYYMMDDHH.jsonl
│   │   └── checkpoint.json
│   ├── extracted_chat/                ← L1 私聊提取
│   │   ├── chat_extracted_YYMMDDHH.jsonl
│   │   └── checkpoint.json
│   └── extracted_group_chat/          ← L1 群聊提取
│       ├── group_chat_extracted_YYMMDDHH.jsonl
│       └── checkpoint.json
├── customers/                         ← L2 客户数据
│   ├── whitelist.json
│   ├── customer-index.md
│   └── {wxid}/
│       └── wechat-analysis/
│           ├── {wxid}_moment_extracted.jsonl
│           └── {wxid}_chat_extracted.jsonl
└── reports/
```


---

## 朋友圈处理

### Moment Phase 1: 数据准备

```bash
python scripts/prepare_data.py
```

扫描 `raw/moments-analysis/` 所有 JSON，比对 `raw/extracted_moment/checkpoint.json` 的 `analyzed_ids`，新帖子通过 stdout 输出。

常见输出（stderr）：

- `OK: N new / M total` → 继续 Phase 2
- `NO_DATA` → 需要先拉取 raw 数据
- `NO_RAW_DIR` → 目录不存在

### Moment Phase 2: Agent 模型抽取

Agent 读取 prepare_data 的 stdout 输出，直接分析 `posts` 数组。

输出 JSON 数组，长度与 `posts` 一致，顺序一一对应。与 posts 合并后通过 stdin 传给 apply_analysis.py。

#### 朋友圈抽取提示词

你是朋友圈商业线索分析助手。请逐条分析输入的朋友圈帖子，输出严格 JSON 数组。

**业务背景：** 我方业务包括定制酒服务、会议/宴请/礼品用酒、贵州文旅产品、创始合伙人/创业投资机会。目标是从朋友圈中识别内容类型、发帖人画像变化、可记录事件和销售线索。

**输出要求：**
- 必须返回 JSON 数组，数组长度必须与输入帖子数量一致
- 每个元素必须是对象，不要输出 null，不要解释，不要 Markdown
- 不确定就留空，禁止编造
- 字段值必须精简，避免完整长句复述原文
- 只基于发帖人正文、位置、评论、互动和媒体数量判断；不要把转发内容中的第三方行为当成发帖人行为

**朋友圈特定关切：**
- events 是**单条朋友圈级别**，每条帖子独立提取
- events 主语为发帖人，用"他"/"她"/"TA"（不用"我"）
- 粒度最细：每条有实质内容的帖子都应产生至少 1 条 event
- traits 是对发帖人本人的画像特征
- signals 允许值严格限定为 6 种

**输出字段：**
```json
{
  "post_type": "转发内容|输出观点|分享动态|广告营销|其他",
  "mood": "开心|失落|焦虑|兴奋|平静|无法判断",
  "traits": {},
  "events": [],
  "signals": []
}
```

### post_type 内容分类

- `转发内容`：转文章、海报、链接、新闻、小程序、视频号等内容，无自己评论
- `输出观点`：发表看法、评论、行业观点、思考，有自身判断
- `分享动态`：发帖人自己的生活、工作、活动、行程，有个人行动
- `广告营销`：产品推广、招商宣传、促销信息
- `其他`：纯表情、纯图片无文字、无法判断

**判断原则：** 内容无法归类填其他。有自身判断输出观点优先，有个人行动分享动态优先，纯招商推广告营销。

### mood 情绪状态

从发帖文字内容和表情中判断发帖人情绪。

**允许值：** 开心、失落、焦虑、兴奋、平静、无法判断

**判断原则：**
- `开心`：庆祝、纪念日、喜悦、成就、正面情绪词
- `失落`：遗憾、失败、告别、负面情绪词
- `焦虑`：担忧、压力、紧张、不确定性表达
- `兴奋`：激动、期待、热情、感叹号密集
- `平静`：中性叙述、日常分享、无明显情绪
- `无法判断`：纯转发无自己评论、空内容、纯图片无文字、纯表情不明确

### traits 画像特征（统一标准）

traits 记录当事人相对稳定的画像，不记录这条内容里出现过什么对象。
只记录有明确证据支撑的特征；证据只能支持动作时，不要上升为画像。

**判断方法：**
- 先问：这条内容能证明当事人本人是什么样，或长期在做什么吗？
- 单次内容也可以写 traits，但证据必须直接指向当事人本人。
- 拿不准时填 `{}`。

**Key 仅允许使用以下 18 个，禁止自创：**
所在城市、婚姻状况、学历、毕业院校、在职单位、职务、行业、家庭结构、社交圈层、人脉资源、性格特征、表达风格、兴趣爱好、价值观倾向、资产档次、投资风格、饮酒偏好、香型偏好

**Value 规范：**
- 有依据的具体描述。
- 每条少于 10 个汉字。
- 禁止"未知""待确认""推测"等占位符。
- 正文少于 30 字或无有效信息时，traits 填 {}。
- 纯转发且无法推断发帖人特征时，traits 填 {}。

**示例：**

正确：
- 朋友圈：A 发帖说"我长期做海外渠道，今年主要看东南亚。"
  输出：`{"关注点": "东南亚渠道"}`
- 私聊：A 说"这个客户一直由我对接，后续我来跟。"
  输出：`{"职责": "客户对接"}`
- 群聊：A 多次用数据拆解行业问题，并给出自己的判断。
  输出：`{"A": "表达风格：数据分析"}`

错误：
- 朋友圈：A 转发"德国前总统出席企业家私享会"。
  错误：`{"人脉资源": "德国前总统"}`
  原因：德国前总统是内容对象，不是 A 本人的属性。
- 私聊：A 说"我把匀东贵州饭店加进名单。"
  错误：`{"职务": "酒店拓展"}`
  原因：只能证明 A 做了这件事，不能证明 A 的稳定职务。
- 群聊：A 问"今天谁订晚餐，3 点前填表。"
  错误：`{"A": "职务：行政"}`
  原因：一次通知不能证明稳定角色。

### events 事件提取（统一标准）

记录发帖人亲身经历、主动发起、明确参与或与其业务/生活状态直接相关的具体行动。

**重要原则：**
- events 与 signals 独立。没有销售机会，也要抽取具体事件。
- 不要因为事件暂时不适合行动建议就漏掉。
- 只要能说明"这个人最近发生了什么/做了什么/参与了什么"，且不是纯噪声，就应进入 events。
- 同一条内容里有多个明确事件时，优先全部列出，不要只保留一个总结性事件。
- 对有明确时间、地点、人物、组织或业务动作的事件，宁可多抽取，再由后续报告承接展示。
- 同一事实不要拆成"具体事件 + 泛化事件"两条；例如已有"联合承办上海市场学会品牌论坛"，不要再输出"参加论坛"。
- 同一业务目的、同一活动或同一项目进展下的多个动作合并为一条；例如"接待校友到访并参加座谈会"应合并为一个座谈会事件，"需求扩容、城市增加、领取需求表"应合并为一个需求扩容事件。
- 保留对业务判断有价值的实体信息，优先包含地点、机构、品牌、项目名、活动名、客户或产品名。

**格式要求：**
- 动词开头，只讲一件事，抓主要矛盾。
- 能回答"谁 + 做了什么 / 去了哪里"。
- 每条少于 30 字；为了保留关键实体，可适度长于普通短语。
- 必须是完整短语，禁止截断原文半句话。
- events 不设固定条数上限；能明确识别的事件先全部输出。
- 若两个候选事件指向同一行动，保留信息更完整的一条，删除泛化或重复表达。
- 若多个候选事件共享同一目的，保留"目的 + 关键实体 + 核心动作"的合并表达，不拆过程步骤。

**应该抽取的事件类型：**
- 商务活动：参加会议、论坛、沙龙、座谈会、路演、展会、招商会、签约仪式。
- 项目进展：项目上线、启动运营、发布新品、开工、交付、承办活动、客户到访。
- 组织动作：举办团建、发起活动、接待来访、开放报名、招募资源、发布需求。
- 出行活动：出差、旅行、抵达某地、参加线下活动，地点明确时可记录。
- 人生节点：结婚、订婚、生日、乔迁、开业、升学、满月、周岁、封坛储酒等。
- 专业动态：发表研究、发布报告、参与公益行、行业合作、校友/协会活动。
- 消费/社交场景：明确的商务宴请、饭局、聚会、品鉴、客户接待。

**禁止提炼为 event 的情况：**
- 社交用语，例如"晚上见""来了"。
- 状态标签，例如"高强度工作"。
- 纯信息发布，例如"发布通知""转发文章"。
- 纯转发内容中的第三方活动。
- 广告话术或招商宣传，除非能确认是发帖人本人组织或参与。
- 低价值日常记录，例如早安问候、餐食碎片、无明确地点或动作的普通打卡；这类信息可放入 traits，不进入 events。
- 只有观点、鸡汤、财经新闻、行业评论，没有发帖人动作时，不进入 events。

**正确示例：**
- "抵达北京西站"
- "参加医药合规座谈会"
- "接待中国药大校友参加云溪医药合规座谈会"
- "组织客户回厂参观"
- "举办公司周年庆"
- "联合承办上海市场学会品牌论坛"
- "预告项目签约仪式"
- "预告AIROBO和泓服务签约仪式"
- "发布海外媒体需求"
- "扩容海外来华项目30城媒体需求"
- "客户别墅开工"
- "举办团建温泉活动"
- "完成白俄明斯克空运"

**错误示例：**
- "高强度工作"
- "博鳌乐城高端体检"
- "吴向东珍酒直播烤酒车间"
- "发布求职信息"
- "早安问候"
- "参加论坛"（已有具体论坛名称时过于泛化）
- "启动项目"（已有具体项目名或活动名时过于泛化）
- "接待中国药大校友到云溪指导"和"参加医药合规座谈会"同时输出（应合并）
- "扩容海外媒体需求"和"发布媒体资源需求"同时输出（应合并）

### signals 销售信号（统一标准）

signals 只记录需求方线索。满足以下全部条件才可标记：

1. 发帖人或对话对象表现出采购、使用、送礼、宴请、会议伴手礼、企业定制、婚宴定制、文旅体验或合伙人了解意向。
2. 我方产品或服务有机会介入。
3. 原文中有明确证据支持该需求。

供给侧内容不进入 signals。供给侧内容包括：发帖人在销售、招商、推广、代理、宣传自己的酒类产品、酒类品牌、酒类课程、酒类媒体或酒类服务。

如果内容是酒类相关，但角色是供给方，`signals` 必须为空；可保留为 `post_type: "广告营销"` 或 `events`，但不作为销售线索。

**允许值限定为：**
- 婚宴定制酒
- 企业定制酒
- 会议伴手礼
- 宴请用酒
- 节日礼盒
- 合伙人机会

**强信号类型：**
- 人生节点：婚礼、订婚、满月、周岁、升学、乔迁、开业、周年庆、寿宴，且存在用酒、送礼、宴请或定制场景。
- 需求场景：明确出现伴手礼、封坛储酒、企业定制、婚宴用酒、会议用酒、礼盒、宴请接待等需求。
- 活动场景：发帖人是活动组织者、参与者或需求方，且活动存在我方可介入的用酒、礼品、宴请、会议伴手礼需求。
- 投资/创业：本人创业、融资、新项目落地、寻找合伙人，且不是泛泛资讯转发。

**禁止标记为 signals：**
- 纯消费展示，例如酒柜、喝酒晒图。
- 饮酒偏好表达，例如"只喝酱香"。
- 一般商务动态，但没有采购或场景需求。
- 对方在卖自己的酒、招商自己的酒、酒类媒体宣传。
- 同行酒业从业者的产品推广，不作为我方营销对象。
- 泛投资资讯、财经新闻、行业观点转发，不等于本人有投资意向。

**正例：**
- "下周公司周年庆，准备伴手礼" -> signals: ["企业定制酒"]
- "参加行业峰会，客户晚宴" -> signals: ["会议伴手礼", "宴请用酒"]
- "婚纱照终于拍完" -> signals: ["婚宴定制酒"]

**反例：**
- "今天喝了茅台"只有饮酒偏好，不是采购机会。
- 酒业同行招商、卖自己产品，不作为我方销售对象。
- 财经新闻转发不等于本人有投资意向。

### Moment Phase 3: 落库

流程：`prepare_data.py` 输出新帖子 → Agent 按顺序抽取 JSON 数组 → 将帖子与抽取结果合并后传给 `apply_analysis.py` 落库。

写入：
- `raw/extracted_moment/moment_extracted_YYYYMMDDHH.jsonl`（L1）
- `customers/{wxid}/wechat-analysis/{wxid}_moment_extracted.jsonl`（L2）
- `raw/extracted_moment/checkpoint.json`

脚本只做字段校验、去重写入、`post_time` 格式化、`rels` 提取、`image_trigger` 计算，不调用模型。

---

## 私聊处理

### Chat Phase 1: 数据准备

```bash
python scripts/prepare_chat.py
```

扫描 `raw/chat-analysis/` 下的私聊 JSONL，按对话对象和日期切分会话段，比对 `raw/extracted_chat/checkpoint.json` 的 `analyzed_ids`，只输出未分析的新段。

常见输出（stderr）：

- `OK: N new segments from M sessions` → 继续 Phase 2
- `NO_NEW_SEGMENTS` → 无需继续私聊抽取
- `NO_RAW_DIR` → 需要先拉取 raw 私聊数据

### Chat Phase 2: Agent 模型抽取

读取 `prepare_chat.py` 的 stdout，按 segment 逐段分析。每段对应一个私聊会话片段。

输出 JSON 数组，长度与 segment 数一致，顺序一一对应。

#### 私聊抽取提示词

你是私聊商业分析助手。逐段分析私聊对话，输出严格 JSON 数组。

**业务背景：** 我方业务包括定制酒服务、会议/宴请/礼品用酒、贵州文旅产品、创始合伙人/创业投资机会。目标是从私聊对话中提取结构化信息，供后续画像和行动建议使用。

**输出要求：**
- 必须返回 JSON 数组，长度与输入段数一致，顺序一一对应
- 每个元素必须是对象，不要输出 null，不要解释，不要 Markdown
- 不确定就留空，禁止编造
- 识别 me 和 peer 双方，从对话中提取对双方的描述

**输出字段：**
```json
{
  "session_overview": {
    "time_start": "YYMMDDTHHmm",
    "time_end": "YYMMDDTHHmm",
    "rounds": 0,
    "initiator": "me|them",
    "volume": "me_dominant|them_dominant|balanced"
  },
  "events": [],
  "traits": {},
  "signals": [],
  "topics": [],
  "rels": {
    "relationship_type": "",
    "attitude": ""
  },
  "todos": []
}
```

### session_overview 会话概览

- `time_start` / `time_end`：YYMMDDTHHmm 格式
- `rounds`：对话往复轮次
- `initiator`：谁先开口（me / them）
- `volume`：一方总字数为另一方 2 倍以上即为 dominant，否则 balanced

### events 事件

同统一规范。**私聊特定关切：**
- events 是**对话层面**的，不是单条消息。一段对话产生 1-3 条 events
- 区分"我"和"TA"：我方动作和对方动作都要记录
- 粒度略粗于朋友圈：不记录每句寒暄，只记录有实质推进的对话节点
- 约定/承诺类事件必须记录，带时间节点

示例："我向TA报价基酒组合方案，总价 50 万"、"TA要求拆分报价明细"、"TA约我下周三当面看样品"、"TA下周去北京出差"

### traits 画像

同统一规范。**私聊特定关切：**
- traits 是对**TA**（对话对象）的推断
- 首次出现的新特征才有价值，已知特征不重复输出

### signals 销售信号

同统一规范。**私聊特定关切：**
- 从 TA 的明确需求表达中判断，我方主动推荐不构成 signal

### topics 话题标签

开放标签列表，按出现顺序。例如 `["基酒投资", "价格谈判", "样品安排"]`。

### rels 关系判断

`relationship_type`：potential_customer / business_partner / old_friend / acquaintance / subordinate / superior / family / other

`attitude`：warm / neutral / cold / defensive / trusting / perfunctory

### todos 待办

提取对话中**未来要做的事**。

判断标准：
- 必须是明确的行动项，不是讨论过的话题、建议、或已完成的
- 可以是"我"要做的，也可以是对方要做的，只要对话中明确约定了后续行动
- deadline 有则写，没有则留空
- 模糊表述如"本周""下周""近期"可以保留

每项 `{content, deadline}`。deadline 不确定时留空字符串。

### Chat Phase 3: 落库

```bash
python scripts/apply_chat_analysis.py --date YYYYMMDDHH
```

脚本将 Agent 模型分析结果写入：

- `raw/extracted_chat/chat_extracted_YYMMDDHH.jsonl`（L1）
- `customers/{talker}/wechat-analysis/{talker}_chat_extracted.jsonl`（L2）
- `customers/{talker}/wechat-analysis/{talker}_relations.jsonl`（关系记录）
- `raw/extracted_chat/checkpoint.json`

---

## 群聊处理

### Group Phase 1: 消息过滤

读取 `raw/group-chat-analysis/group_chat_YYYYMMDDHH.jsonl`。群聊当前没有独立准备脚本，由 Agent 在抽取前先过滤。丢弃以下消息：

- 纯表情/表情包
- 单字回复（"收到""好的""嗯"等）
- 广告/链接轰炸
- 与我无关的闲聊（无 @我、无业务关键词）

保留与我相关或含业务关键词的消息进入下一阶段。

### Group Phase 2: Agent 模型抽取

读取 `raw/group-chat-analysis/group_chat_YYYYMMDDHH.jsonl`，按 session 分析。每条对应一个 session。

#### 群聊抽取提示词

你是群聊商业分析助手。逐段分析群聊对话，输出严格 JSON 数组。

**关注焦点：** 以"我"和"与我相关"为锚点，识别群内的机会和动态。

**输出字段：**
```json
{
  "session_overview": {
    "time_start": "YYMMDDTHHmm",
    "time_end": "YYMMDDTHHmm",
    "rounds": 0
  },
  "topics": [],
  "events": [],
  "traits": {},
  "signals": []
}
```

### session_overview

`time_start` / `time_end`：YYMMDDTHHmm 格式。
`rounds`：对话往复轮次。

### topics 话题标签

从对话内容提取话题标签（如"测试环境"、"代码块优化"、"支付功能"）。

### events 群动态

同统一规范。**群聊特定关切：**
- 群聊 events 是**段级摘要**，不是逐条消息。一段对话提取 2-5 条关键 events
- 主语必须是具体发言人昵称，禁用"有人""某群友"等模糊指代
- 优先记录：与"我"相关的事件、高价值人物发言、业务相关讨论
- 日常闲聊、纯表情回复、无意义刷屏不进入 events
- 粒度最粗：同一话题多人讨论合并为一条，标注关键发言人

示例："张三提到公司正在筹备B轮融资"、"李四推荐了贵阳客户资源给王五"

### traits 画像

同统一规范。**群聊特定关切：**
- 群聊中发言者多、转发多，尤其要区分"发言者本人属性"和"消息内容对象属性"。
- 格式：`{发言人："维度：值"}`。
- 没有足够证据时填 `{}`。

### signals 群聊信号

同统一规范。**群聊特定关切：**
- 只有发言人明确表达需求才标记为 signal
- 转发文章、分享资讯不构成 signal
- 额外关注：某人身份变化、新项目线索、行业动态、有人提需求/问资源/求推荐

### Group Phase 3: 落库

写入：
- `raw/extracted_group_chat/group_chat_extracted_YYMMDDHH.jsonl`（L1）
- `raw/extracted_group_chat/checkpoint.json`

---

## 压缩比对比

| 数据源 | 压缩比 | 关注焦点 | 信号密度 |
|--------|--------|---------|---------|
| 朋友圈 | 约 3:1 | 发帖人动态 | 中 |
| 私聊 | 约 5:1 | 对话双方 | 高 |
| 群聊 | 约 20:1 | 我 + 关键人物 | 低 |

---

## 脚本

| 脚本 | 功能 |
|------|------|
| `scripts/prepare_data.py` | 朋友圈数据准备（去重 + 媒体索引） |
| `scripts/apply_analysis.py` | 朋友圈分析结果落库 |
| `scripts/match_media.py` | 朋友圈媒体文件匹配 |
| `scripts/generate_report.py` | 朋友圈日报生成 |
| `scripts/prepare_chat.py` | 私聊数据准备（扫描 raw 私聊、切分会话段、按 checkpoint 去重） |
| `scripts/apply_chat_analysis.py` | 私聊分析结果落库到 L1、L2 和 checkpoint |
| `scripts/segment_sessions.py` | 私聊原始 JSONL 按 talker 和日期切分的辅助脚本 |

所有脚本不调用模型，模型抽取由当前 Agent 在各数据源的抽取 Phase 中完成。

---

## 执行原则

1. 三种数据源可独立运行，互不依赖。
2. 每种数据源各有自己的 checkpoint，断点续跑。
3. Agent 模型抽取在一条消息内完成，不走外部 API。
4. 落库脚本只做格式化和去重，不做语义判断。
