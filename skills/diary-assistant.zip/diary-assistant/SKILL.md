---
name: diary-assistant
description: 日记助手。当用户要求"写日记"、"记录今天"、"总结对话写日记"、"发布日记到云文档"时使用。自动分析会话摘要，提炼选题，生成配图，发布到飞书云文档"龙虾日记本"。

**Use this skill when:**
(1) User requests "写日记" / "记录今天" / "总结对话写日记" / "发布日记到云文档"
(2) User mentions "日记" / "日记本" / "写日记" / "记录今天" / "总结对话" / "复盘" / "反思" / "心得" / "方法论" / "经验教训"
(3) 定时任务触发：按照 <diary-assistant>技能，执行日记撰写
(4) User wants to analyze conversations and write diary

**Keywords:** 日记，日记本，写日记，记录今天，总结对话，复盘，反思，心得，方法论，经验教训，洞察，发布到云文档
---

# 日记助手

## 一、核心流程

### 1. 读取会话摘要

**触发**：定时任务或用户指令

**执行**：
读取 session-summarizer 生成的摘要文件：
```
C:\Users\44452\.openclaw\chat-logs\summaries\{agent}_{YYYY-MM-DD}_*.md
```

**说明**：
- 扫描 `chat-logs/summaries/` 目录下当天所有摘要文件
- 提取「第一部分：任务视角」和「第二部分：反思视角」内容
- 合并所有 Agent 的摘要作为日记素材

**降级处理**：
如果摘要文件不存在 → 读取原始 ChatLogs 并自行提炼

**输出**：日记素材

---

### 2. 提炼日记选题

**执行**：
从摘要中提炼 3-5 个候选选题，每个选题包含：
- 标题：一句话概括（15 字以内）
- 具体事件：今天发生了什么
- 反思问题：这件事揭示了什么问题
- 洞见方向：可能提炼出什么方法

**提炼维度**（参考）：
- 今天发生了什么重要的事
- 解决了什么问题/有什么突破
- 有什么洞察或反思
- 有什么值得记录的对话或数据

**输出格式**：
```
选题 1：《标题》
- 事件：...
- 问题：...
- 洞见：...

选题 2：《标题》
...
```

---

### 3. 选题研判（subagent）

**目标**：用隔离会话评判哪个选题更抓睛、更有启发性

**执行**：
创建隔离子会话（subagent），发送以下内容：
```
你是日记读者。请评判以下 3-5 个日记选题，从以下维度打分（1-10 分）：
1. 标题吸引力：是否想点击阅读
2. 内容启发性：是否有收获感
3. 转发意愿：是否想点赞/转发
4. 共鸣度：是否有"我也是这样"的感觉

输出格式：
- 综合得分最高的选题 + 理由
- 每个选题的 4 维得分
- 改进建议（如有）
```

**输出**：最佳选题 + 评分理由

---

### 4. 展开成文

**执行**：
根据 subagent 选出的最佳选题，展开成完整日记：

**写作原则**：
- 第一人称：用"我"来写
- 见微知著：从具体事件提炼通用方法
- 有细节：保留关键数据、对话、决策过程
- 可分享：别人看了也能有收获

**篇幅**：800-2000 字

**输出**：完整日记

---

### 5. 生成配图

**目标**：Q 萌龙虾 + 剧情性，体现当天主题

**执行**：
根据日记主题生成封面图：

**提示词模板**：
```
一只 Q 萌的卡通龙虾，[当天主题关键词]，
风格：简约、可爱、有剧情性，
色调：温暖、启发性的配色，
尺寸：16:9（适合飞书文档展示）
```

**示例**：
- 主题"工欲善其事必先利其器" → 龙虾拿着工具打磨技能
- 主题"隔离会话的价值" → 龙虾在两个房间之间对比文件
- 主题"见微知著" → 龙虾用放大镜看小细节，背后是大场景

**保存路径**：
```
C:\Users\44452\.openclaw\agents\guaiguaixia\workspace\scratchpad\diary-YYYY-MM-DD.png
```

---

### 6. 发布到飞书云文档

**执行**：

**步骤 1：复制文件到临时目录**
```powershell
$sourcePath = "C:\Users\44452\.openclaw\agents\guaiguaixia\workspace\scratchpad\diary-YYYY-MM-DD.png"
$tempPath = "C:\Users\44452\AppData\Local\Temp\diary-YYYY-MM-DD.png"
Copy-Item $sourcePath $tempPath -Force
```

**步骤 2：搜索"龙虾日记本"文档**
```
feishu_search_doc_wiki(query="龙虾日记本")
```

**步骤 3：插入配图（使用 feishu_doc_media）**
```
feishu_doc_media(
  action="insert",
  doc_id="文档 ID",
  file_path="C:\\Users\\44452\\AppData\\Local\\Temp\\diary-YYYY-MM-DD.png",
  type="image",
  align="center",
  caption="📅 YYYY-MM-DD 日记封面"
)
```

**注意**：
- 必须使用 feishu_doc_media，不能用 feishu_drive_file
- 先配图，后文字
- 内容较长时分段追加，每段 < 1000 字

**步骤 4：追加日记正文**
```
feishu_update_doc(
  doc_id="文档 ID",
  markdown="日记内容",
  mode="append"
)
```

---

## 二、日记选题方法

**核心原则**：日记不是流水账，而是从具体事件创作出对"用龙虾这件事"的启发

**创作 vs 记录的区别**：
- 记录：今天做了什么（流水账）
- 创作：从这件事中学到了什么，对其他人有什么启发（见微知著）

**选题来源**：
- 今天花最多时间的事（>30 分钟）
- 用户反复纠正的事（说明 AI 容易错）
- 第一次成功的方法（如 subagent 隔离审计）
- 从"没感觉"到"有感觉"的转变过程

**选题结构**：
```
具体事件 → 反思（提出问题） → 启发（解决方案） → 对读者的价值
```

**好标题的特征**：
- 15 字以内
- 有画面感（如"工欲善其事必先利其器"）
- 有反差感（如"为什么 AI 说'我理解了'反而不可信"）
- 有普适性（其他用户也能用）

---

## 三、日记风格指导

**写作原则**：
- ✅ 第一人称：用"我"来写，像跟自己对话
- ✅ 见微知著：从具体事件提炼通用方法
- ✅ 有细节：保留关键数据、对话、决策过程
- ✅ 可分享：别人看了也能有收获
- ❌ 避免：过度分段、太多小标题、机械的"事件 1/事件 2"格式
- ❌ 避免：流水账、空洞的总结、技术调试记录

**篇幅**：800-2000 字

---

## Usage Logging (Auto-injected)

每次技能触发时，自动记录到 `~/.openclaw/skill-logs/diary-assistant/log.md`：

```bash
mkdir -p ~/.openclaw/skill-logs/diary-assistant
echo "## [$(date '+%Y-%m-%d %H:%M:%S')]" >> ~/.openclaw/skill-logs/diary-assistant/log.md
echo "- **日期**: YYYY-MM-DD" >> ~/.openclaw/skill-logs/diary-assistant/log.md
echo "- **选题**: <selected topic>" >> ~/.openclaw/skill-logs/diary-assistant/log.md
echo "- **结果**: 成功/失败" >> ~/.openclaw/skill-logs/diary-assistant/log.md
echo "" >> ~/.openclaw/skill-logs/diary-assistant/log.md
```

---

_创建时间：2026-04-04_
_版本：2.0.0（会话摘要 + subagent 研判版）_
_最后修改：2026-04-05_
