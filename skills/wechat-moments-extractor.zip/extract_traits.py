"""画像特征提取脚本"""
import json, sys, os
sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from shared_api import call_with_fallback

SYSTEM_PROMPT = '''【画像特征提取】
从内容中提取发帖人的特征信息。

特征维度（仅供参考，不强制填满）：
- 基础信息：年龄、所在城市、婚姻状况
- 教育与工作：学历、毕业院校、在职单位、职务、行业
- 收入与资产：房产、股票等资产配置
- 家庭与关系：家庭结构、社交圈层、人脉资源
- 个人特质：性格、表达风格、兴趣爱好、价值观倾向
- 消费水平：资产档次（名车、名表、豪宅等）
- 投资风格：权益类/固收类等资产配置方式
- 饮酒偏好：常喝什么品牌/香型

格式：{"维度名":"特征值"}，无信息则不填。

禁止：
- 禁止从微信号/昵称提取画像
- 禁止填入占位符（如"待确认"、"未知"）
- 在职单位必须是具体公司，不能是品类/商品
- 内容不足30字无法提取画像：traits填{}
- 纯转发无个人观点：只从昵称和原文标题推断，无法推断填{}
- 某条分析失败：该条填{}

输出JSON数组，每条只有traits字段。'''


def extract_traits(posts, api_key, base_url, fallback_configs=None):
    result = call_with_fallback(posts, SYSTEM_PROMPT, api_key, base_url, fallback_configs)
    if result is None:
        return [{}] * len(posts)
    return [
        (item.get('traits', {}) if isinstance(item, dict) and isinstance(item.get('traits'), dict) else {})
        for item in result
    ]


if __name__ == '__main__':
    cfg_path = os.path.expanduser('~/.openclaw/openclaw.json')
    with open(cfg_path, 'r', encoding='utf-8') as f:
        cfg = json.load(f)
    ali = cfg['models']['providers']['aliyun-bailian']
    test_posts = [{'nickname': '杨香雪儿', 'content': '和双币基金朋友介绍项目后干饭'}]
    print(json.dumps(extract_traits(test_posts, ali['apiKey'], ali['baseUrl']), ensure_ascii=False))
