# 测试上传单个文件到飞书多维表格
# API: POST /open-apis/drive/v1/media/upload_all

$appToken = "Ms0Sbx75jahr5QsX4vQc8rnxn2f"
$testFile = "C:\Users\44452\.openclaw\workspace\skills\_packages\agent-tools.zip"

Write-Host "测试上传文件到多维表格..." -ForegroundColor Green
Write-Host "文件: $testFile"
Write-Host "App Token: $appToken"

# 获取 access_token（需要从飞书插件获取）
# 这里需要调用 openclaw 来获取 token

Write-Host "`n请使用以下命令测试上传：" -ForegroundColor Yellow
Write-Host "openclaw chat send --message '上传文件 $testFile 到多维表格 $appToken 作为附件，使用 parent_type=bitable_file'"
