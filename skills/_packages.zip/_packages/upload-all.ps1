# 批量上传 skill 文件到多维表格
$appToken = "Ms0Sbx75jahr5QsX4vQc8rnxn2f"
$tableId = "tbl3gLHsyjGGl7iN"
$packagesDir = "C:\Users\44452\.openclaw\workspace\skills\_packages"

# Skill 名称到 record_id 的映射
$skillMap = @{
    "agent-tools" = "recvdCWu0W8FPZ"
    "api-manager" = "recvdCWu0WiykL"
    "browser-automation" = "recvdCWpotmeej"
    "capability-evolver" = "recvdPwmv3i0p9"
    "cloudflare-deploy" = "recvdCWu0WesLS"
    "conversation-save" = "recvdCWu0WVqoa"
    "feishu-auto-reply" = "recvdCWFVYMDiq"
    "feishu-bitable" = "recvdCWpotrcX2"
    "feishu-calendar" = "recvdCWpotmiF2"
    "feishu-channel-rules" = "recvdCWu0WsCNA"
    "feishu-create-doc" = "recvdCWpotFAK5"
    "feishu-fetch-doc" = "recvdCWpotWH3h"
    "feishu-im-read" = "recvdCWu0WzxNk"
    "feishu-task" = "recvdCWpot39In"
    "feishu-troubleshoot" = "recvdCWu0WaqiI"
    "feishu-update-doc" = "recvdCWu0W3oDh"
    "gateway-restart" = "recvdPwmv3kzMi"
    "interview-tracker" = "recvdPwmv3iANA"
    "swap" = "recvdPwp3VNrW5"
    "task-monitor" = "recvdCWCrMKJab"
    "todolist-manager" = "recvdCWFVYhgf2"
    "wechat-analyzer" = "recvdCWCrMePbh"
    "weflow" = "recvdCWCrMbURk"
    "coding-agent" = "recvdCWpotq1hC"
    "weather" = "recvdCWpotAX5m"
    "github" = "recvdCWpot4bIG"
    "skill-creator" = "recvdCWpotuSOJ"
    "clawhub" = "recvdCWu0WFKuz"
    "gh-issues" = "recvdCWu0WUoW9"
    "healthcheck" = "recvdCWCrM2qU7"
    "openai-whisper" = "recvdCWCrMR07q"
    "video-frames" = "recvdCWCrMtpsY"
    "self-improving-agent" = "recvdCWCrMqqTK"
    "agent-comm" = "recvdCWCrMyozu"
    "project-manager" = "recvdCWCrMAeO3"
    "web-designer" = "recvdCWCrMLWiD"
    "test-skill-from-agent" = "recvdPwp3VnLi8"
}

$zipFiles = Get-ChildItem -Path $packagesDir -Filter "*.zip"
$total = $zipFiles.Count
$current = 0

foreach ($zipFile in $zipFiles) {
    $current++
    $skillName = $zipFile.BaseName
    $recordId = $skillMap[$skillName]
    
    if (-not $recordId) {
        Write-Host "[$current/$total] 跳过: $skillName (未找到 record_id)" -ForegroundColor Yellow
        continue
    }
    
    Write-Host "[$current/$total] 上传: $skillName" -ForegroundColor Cyan
    
    # 上传文件
    $uploadCmd = "openclaw chat send --message `"上传文件 $($zipFile.FullName) 到多维表格 $appToken，parent_type=bitable_file，返回 file_token`""
    $result = Invoke-Expression $uploadCmd
    
    Write-Host "  完成: $skillName" -ForegroundColor Green
    Start-Sleep -Milliseconds 500
}

Write-Host "`n所有文件上传完成！" -ForegroundColor Green
