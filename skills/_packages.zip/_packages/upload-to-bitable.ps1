# 批量上传 skill zip 文件到飞书多维表格
# 使用飞书 SDK 的 uploadAll 接口

$appToken = "Ms0Sbx75jahr5QsX4vQc8rnxn2f"
$tableId = "tbl3gLHsyjGGl7iN"
$fieldId = "fldMD7ZN2e"
$packagesDir = "C:\Users\44452\.openclaw\workspace\skills\_packages"

Write-Host "开始上传 skill 文件包到多维表格..." -ForegroundColor Green

# 获取所有 zip 文件
$zipFiles = Get-ChildItem -Path $packagesDir -Filter "*.zip"
Write-Host "找到 $($zipFiles.Count) 个 zip 文件"

foreach ($zipFile in $zipFiles) {
    $skillName = $zipFile.BaseName
    Write-Host "`n处理: $skillName" -ForegroundColor Cyan
    
    # 1. 上传文件到多维表格
    Write-Host "  上传文件..."
    $uploadResult = openclaw chat send --message "使用飞书 SDK 上传文件 $($zipFile.FullName) 到多维表格 $appToken，parent_type 为 bitable_file"
    
    # 这里需要解析返回的 file_token
    # 然后更新对应的记录
    
    Write-Host "  完成: $skillName" -ForegroundColor Green
}

Write-Host "`n所有文件上传完成！" -ForegroundColor Green
