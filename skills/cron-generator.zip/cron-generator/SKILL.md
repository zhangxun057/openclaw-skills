---
name: cron-generator
description: 定时任务创建与管理技能。当用户要求创建定时任务、设置提醒、预约执行任务时使用。掌握 OpenClaw 定时任务的完整方法论，包括命令使用、配置结构、Message 规范。
---

# 定时任务创建与管理技能

## 触发条件
- 用户要求"创建定时任务"、"设置提醒"、"预约执行"
- 用户询问"如何配置定时任务"、"定时任务怎么写"
- 用户要求修改现有定时任务的 message

## 核心知识

### 1. 定时任务 vs 心跳

**定时任务（Cron）**：
- 精确定时执行（如每天9:00）
- 存储位置：`~/.openclaw/cron/jobs.json`
- 创建方式：`openclaw cron add` 命令
- 用途：需要精确时间的任务

**心跳（Heartbeat）**：
- 周期性批量检查（如每30分钟）
- 配置位置：`HEARTBEAT.md` 文件
- 用途：多个检查项批量处理

**重要**：定时任务与心跳无关，不要混淆！

---

## 2. 创建定时任务

### ⚠️ 重要：时间时区规则（北京时间）

**用户说的所有时间都是北京时间（Asia/Shanghai）。**

创建 cron 任务时，**必须**添加 `--tz "Asia/Shanghai"` 参数：

```bash
openclaw cron add \
  --name "任务名称" \
  --cron "0 9 * * *" \
  --tz "Asia/Shanghai" \
  --session isolated \
  --message "任务指令"
```

**示例：**
- 用户说"每天早上9点" → `--cron "0 9 * * *" --tz "Asia/Shanghai"`
- 用户说"晚上11点半" → `--cron "30 23 * * *" --tz "Asia/Shanghai"`
- 用户说"13:20" → `--cron "20 13 * * *" --tz "Asia/Shanghai"`

**不加 `--tz` 时，Gateway 默认使用 UTC**，导致任务比预期晚8小时执行。

---

### 命令格式

```bash
openclaw cron add \
  --name "任务名称" \
  --cron "0 9 * * *" \
  --tz "Asia/Shanghai" \
  --session isolated \
  --message "任务指令" \
  --announce \
  --channel feishu \
  --to "user:ou_xxx" \
  --best-effort
```

### 关键参数

| 参数 | 说明 | 示例 |
|------|------|------|
| `--name` | 任务名称 | "daily-work-brief" |
| `--cron` | Cron表达式 | "0 9 * * *"（每天9点） |
| `--tz` | 时区 | "Asia/Shanghai" |
| `--session` | 会话类型 | isolated / main |
| `--message` | 任务指令（核心！） | 见下文规范 |
| `--announce` | 投递模式 | 投递摘要 |
| `--channel` | 渠道 | feishu |
| `--to` | 接收者 | "user:ou_xxx" |
| `--best-effort` | 投递失败不报错 | 推荐添加 |

---

## 3. Message 规范（核心）

### 规则1：有 Skill 支持

**格式**：
```
按照 <技能名>技能，执行"任务名称"
```

**示例**：
- `按照 <skill-radar>技能，执行"每日技能扫描"`
- `按照 <diary-assistant>技能，执行"日记撰写"`
- `按照 <todolist-manager>技能，执行"每日复盘"并生成工作简报`

**要点**：
- 用 `<技能名>技能` 格式明确标识
- "任务名称" 必须是 Skill 文档中明确定义的入口点
- 删除所有实现细节（Skill 内部已定义）

### 规则2：无 Skill 支持

**格式**：
```
执行XX任务：
1. 具体步骤（包括API路径、参数）
2. 处理要求
3. 存储位置（完整路径）
```

**示例**：
```
执行InStreet学习任务：
1.调用InStreet API获取技能分享热门帖子（/api/v1/posts?submolt=skills&sort=hot&limit=10）
2.提取有价值的内容摘要
3.写入知识库 knowledge/instreet-learnings/YYYY-MM-DD.md
```

**要点**：
- 必须写得具体、充分、详细
- 包含 API 路径、参数、文件路径
- 无 Skill 支持的任务容易低质量，所以要写得更紧

### 规则3：禁止的废话

**删除以下内容**：
- ❌ "推送给张总"（delivery 配置控制）
- ❌ "发送给用户"（delivery 配置控制）
- ❌ "生成简报发送"（delivery 自动处理）

---

## 4. 配置文件结构

### 存储位置
```
~/.openclaw/cron/
├── jobs.json              # 任务配置（核心）
├── jobs.json.bak          # 备份文件
└── runs/                  # 执行历史
    └── <jobId>.jsonl      # 每个任务的运行记录
```

### jobs.json 结构

```json
{
  "version": 1,
  "jobs": [
    {
      "id": "任务ID",
      "agentId": "执行者（哪只虾）",
      "name": "任务名称",
      "description": "任务描述（给人看）",
      "enabled": true,
      "schedule": {
        "kind": "cron",
        "expr": "0 9 * * *"
      },
      "sessionTarget": "isolated",
      "wakeMode": "now",
      "payload": {
        "kind": "agentTurn",
        "message": "任务指令（给AI看，核心！）",
        "thinking": "off"
      },
      "delivery": {
        "mode": "announce",
        "channel": "feishu",
        "to": "user:ou_7a7dc2b5500d01e1863a26e145bf1b58",
        "bestEffort": true
      },
      "state": {
        "nextRunAtMs": 下次运行时间,
        "lastRunStatus": "ok/error"
      }
    }
  ]
}
```

### 关键字段说明

**description vs message**：
- `description`：给人看的，方便管理识别
- `message`：给 AI 看的，真正执行的指令

**delivery 配置**：
- `mode`: "announce"（投递摘要）或 "none"（不投递）
- `channel`: "feishu"
- `to`: "user:ou_7a7dc2b5500d01e1863a26e145bf1b58"（张总的 open_id）
- `bestEffort`: true（投递失败不影响任务状态）

**agentId 自动匹配 bot**：
- agentId: "guaiguaixia" → 通过乖乖虾 bot 发送
- agentId: "pipipixia" → 通过皮皮虾 bot 发送
- 通过 openclaw.json 的 bindings 配置自动路由

---

## 5. 实战示例

### 示例1：有 Skill 支持的任务

```bash
openclaw cron add \
  --name "daily-work-brief" \
  --cron "0 9 * * *" \
  --tz "Asia/Shanghai" \
  --session isolated \
  --agent guaiguaixia \
  --message "按照 <todolist-manager>技能，执行\"每日复盘\"并生成工作简报" \
  --announce \
  --channel feishu \
  --to "user:ou_7a7dc2b5500d01e1863a26e145bf1b58" \
  --best-effort
```

### 示例2：无 Skill 支持的任务

```bash
openclaw cron add \
  --name "instreet-morning-learn" \
  --cron "0 9 * * *" \
  --tz "Asia/Shanghai" \
  --session isolated \
  --agent pipipixia \
  --message "执行InStreet学习任务：1.调用InStreet API获取技能分享热门帖子（/api/v1/posts?submolt=skills&sort=hot&limit=10）2.提取有价值的内容摘要 3.写入知识库 knowledge/instreet-learnings/YYYY-MM-DD.md" \
  --announce \
  --channel feishu \
  --to "user:ou_7a7dc2b5500d01e1863a26e145bf1b58" \
  --best-effort
```

---

## 6. 常见问题

### Q1: 如何查看现有任务？
```bash
openclaw cron list
```

### Q2: 如何修改任务？
```bash
openclaw cron edit <jobId> --message "新的指令"
```

或直接编辑 `~/.openclaw/cron/jobs.json`（需重启 Gateway）

### Q3: 如何查看执行历史？
```bash
openclaw cron runs --id <jobId> --limit 10
```

或查看 `~/.openclaw/cron/runs/<jobId>.jsonl`

### Q4: 投递失败怎么办？
- 添加 `bestEffort: true`，投递失败不影响任务状态
- 结果仍保存在 runs 历史中，可手动查看

### Q5: 如何确保投递到正确的 bot？
- 通过 `agentId` 自动匹配
- openclaw.json 的 bindings 配置确保路由正确

---

## 7. 补偿执行机制

**重要**：Gateway 关闭时，定时任务不会执行。

**补偿机制**：
- 早上打开电脑启动 Gateway 后
- 会立即补偿执行错过的任务
- 例如：22:00 的任务在 08:55 执行（补偿昨晚错过的）

**nextRunAtMs 字段**：
- 记录下次执行时间
- 补偿执行后会正确计算下次时间

---

## 8. 使用流程

### 创建新任务的步骤

1. **确认是否有 Skill 支持**
   - 有 Skill：检索 Skill 文档，找到明确的入口点
   - 无 Skill：准备详细的执行步骤

2. **编写 message**
   - 有 Skill：`按照 <技能名>技能，执行"任务名称"`
   - 无 Skill：详细步骤（API、参数、路径）

3. **确定投递对象**
   - 张总：`user:ou_7a7dc2b5500d01e1863a26e145bf1b58`
   - 其他用户：使用对应的 open_id

4. **执行创建命令**
   - 使用 `openclaw cron add`
   - 必须添加 `--best-effort`

5. **验证配置**
   - 查看 `~/.openclaw/cron/jobs.json`
   - 确认 message、delivery 配置正确

---

## 9. 注意事项

1. **不要混淆定时任务和心跳**
   - 定时任务：`openclaw cron add`
   - 心跳：`HEARTBEAT.md` 文件

2. **message 是核心**
   - 有 Skill：简洁钩子
   - 无 Skill：详细步骤

3. **投递信息在 delivery 配置**
   - 不要写在 message 里

4. **bestEffort 必须添加**
   - 避免投递失败导致任务失败

5. **agentId 决定 bot**
   - 自动匹配对应的飞书 bot

---

## 10. 推送对象规则（重要）

**不同飞书 Bot 应用下，同一用户的 open_id 不同**。

**配置 delivery.to 时必须根据 agentId 查表选择正确的 open_id**：

| agentId | Bot 名称 | delivery.to (张洵的 open_id) |
|---------|---------|------------------------------|
| `main` | 丑丑虾 | `ou_fa304d207540db7ee7356a1ef4d5285c` |
| `guaiguaixia` | 乖乖虾 | `ou_7a7dc2b5500d01e1863a26e145bf1b58` |
| `pipipixia` | 皮皮虾 | `ou_3a0621bedd0f31492ef308bd46c639c9` |
| `lelexia` | 乐乐虾 | `ou_b94f7aafa35110399b6bfaf8eaf79621` |
| `zhuizhuixia` | 锥锥虾 | `ou_09b5add8a30ccf45b5919a84d29e34a8` |

**查询位置**：`~/.openclaw/apis.md` → 第 3.3 节 "飞书 Bot 对应张洵的 OpenID"

**错误示例**（皮皮虾用了乖乖虾的 ID）：
```json
{
  "agentId": "pipipixia",
  "delivery": {
    "to": "user:ou_7a7dc2b5500d01e1863a26e145bf1b58"  // ❌ 错误！这是乖乖虾的 ID
  }
}
```

**正确示例**：
```json
{
  "agentId": "pipipixia",
  "delivery": {
    "to": "ou_3a0621bedd0f31492ef308bd46c639c9"  // ✅ 正确！皮皮虾的 ID
  }
}
```

---

_Created: 2026-03-21_
_Version: 2.1_
_Last Updated: 2026-03-23 - 添加推送对象规则_
