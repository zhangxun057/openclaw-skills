---
name: feishu-bitable-upload
description: 飞书多维表格附件上传。OpenClaw 的 feishu_drive_file 工具不支持 parent_type 参数,需直接调用飞书 API。提供完整的 Python 脚本实现。
author: 张洵
source: 实战经验（2026-03-18）
---

# 飞书多维表格附件上传

## 核心问题

**OpenClaw 工具限制**: `feishu_drive_file` 工具不支持 `parent_type` 参数,无法上传到多维表格。

**解决方案**: 直接调用飞书原生 API,使用 `parent_type: "bitable_file"`。

## 使用方法

### 命令行上传

```bash
cd ~/.openclaw/skills/feishu-bitable-upload/scripts
python upload_attachment.py <文件路径> <app_token> <table_id> <record_id> <字段名>
```

**示例**:
```bash
python upload_attachment.py \
  ~/image.jpg \
  Ms0Sbx75jahr5QsX4vQc8rnxn2f \
  tblU1u2KzTmZIqdw \
  recvdV2cCDZcM7 \
  "任务交付物"
```

### Python 调用

```python
import sys
sys.path.append('~/.openclaw/skills/feishu-bitable-upload/scripts')
from upload_attachment import upload_to_bitable

result = upload_to_bitable(
    file_path='path/to/file.jpg',
    app_token='Ms0Sbx75jahr5QsX4vQc8rnxn2f',
    table_id='tblU1u2KzTmZIqdw',
    record_id='recvdV2cCDZcM7',
    field_name='任务交付物'
)
```

## 飞书应用凭证获取

### 方式1: 从 openclaw.json 读取(推荐)

脚本会自动从 `~/.openclaw/openclaw.json` 读取飞书应用凭证:

```json
{
  "channels": {
    "feishu": {
      "accounts": {
        "main": {
          "appId": "cli_a926f9e47e38dbc4",
          "appSecret": "dTQAAdpVHVIzrMvbRWLPAdB1mN0eTqlq"
        }
      }
    }
  }
}
```

**如果 openclaw.json 中没有配置**,按方式2手动获取。

### 方式2: 从飞书开放平台获取

1. 访问 https://open.feishu.cn/app
2. 登录你的飞书账号
3. 找到你的应用(如果没有,点击"创建企业自建应用")
4. 点击应用名称进入详情页
5. 左侧菜单选择"凭证与基础信息"
6. 复制 `App ID` 和 `App Secret`
7. 更新到 `~/.openclaw/openclaw.json` 的对应位置

**权限要求**:
应用需要开通以下权限:
- 查看、评论、编辑和管理多维表格 (bitable:app)
- 上传图片和附件到云文档中 (docs:document.media:upload)

**如何开通权限**:
1. 在应用详情页,点击"权限管理"
2. 搜索并开通上述权限
3. 点击"创建版本"并发布应用

## 工作原理

### 步骤1: 获取 tenant_access_token
```python
POST https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal/
{
  "app_id": "cli_xxx",
  "app_secret": "xxx"
}
```

### 步骤2: 上传文件到多维表格
```python
POST https://open.feishu.cn/open-apis/drive/v1/medias/upload_all
Headers: Authorization: Bearer <token>
Form Data:
  - file_name: "image.jpg"
  - parent_type: "bitable_file"  # 关键参数
  - parent_node: <app_token>
  - size: <file_size>
  - file: <binary>
```

### 步骤3: 更新多维表格记录
```python
PUT https://open.feishu.cn/open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/records/{record_id}
{
  "fields": {
    "附件字段名": [{"file_token": "xxx"}]
  }
}
```

## 常见问题

### 1. 为什么不用 OpenClaw 的 feishu_drive_file?
OpenClaw 的工具不支持 `parent_type` 参数,无法指定上传到 bitable。

### 2. 网络代理问题
脚本已禁用代理 (`session.trust_env = False`),避免连接失败。

### 3. 字段名错误
使用 `feishu_bitable_app_table_field` 工具查看正确的字段名:
```python
feishu_bitable_app_table_field({
  action: "list",
  app_token: "xxx",
  table_id: "xxx"
})
```

### 4. 文件大小限制
- 单文件最大 20MB
- 超过 20MB 需使用分片上传接口

## 限制

- 单文件最大 20MB（飞书 API 限制）
- 批量更新最多 500 条记录/次
- 每个附件字段最多 10 个附件

## 参考

- 飞书上传素材 API: https://open.feishu.cn/document/server-docs/docs/drive-v1/upload
- 飞书多维表格记录 API: https://open.feishu.cn/document/server-docs/docs/bitable-v1/app-table-record/create
