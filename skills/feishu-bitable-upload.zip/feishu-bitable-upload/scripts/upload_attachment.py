#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""上传附件到飞书多维表格"""
import sys
import os
import json
import requests

def get_token():
    """从 openclaw.json 获取 tenant_access_token"""
    config_path = os.path.expanduser('~/.openclaw/openclaw.json')
    
    if not os.path.exists(config_path):
        print("错误: 找不到 openclaw.json 配置文件")
        print("请确认 OpenClaw 已正确安装")
        sys.exit(1)
    
    with open(config_path, 'r', encoding='utf-8') as f:
        config = json.load(f)
    
    try:
        app_id = config['channels']['feishu']['accounts']['main']['appId']
        app_secret = config['channels']['feishu']['accounts']['main']['appSecret']
    except KeyError:
        print("错误: openclaw.json 中未配置飞书应用凭证")
        print("\n请按以下步骤获取:")
        print("1. 访问 https://open.feishu.cn/app")
        print("2. 登录并选择你的应用(或创建新应用)")
        print("3. 点击'凭证与基础信息'")
        print("4. 复制 App ID 和 App Secret")
        print("5. 更新到 ~/.openclaw/openclaw.json:")
        print('   "channels" -> "feishu" -> "accounts" -> "main" -> "appId" 和 "appSecret"')
        sys.exit(1)
    
    session = requests.Session()
    session.trust_env = False
    
    resp = session.post(
        'https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal/',
        json={'app_id': app_id, 'app_secret': app_secret}
    )
    result = resp.json()
    if result.get('code') != 0:
        raise Exception(f"获取 token 失败: {result}")
    
    return result['tenant_access_token']

def upload_to_bitable(file_path, app_token, table_id, record_id, field_name):
    """上传文件到多维表格附件字段"""
    token = get_token()
    session = requests.Session()
    session.trust_env = False
    
    # 步骤1: 上传文件
    file_size = os.path.getsize(file_path)
    files = {'file': (os.path.basename(file_path), open(file_path, 'rb'))}
    data = {
        'file_name': os.path.basename(file_path),
        'parent_type': 'bitable_file',
        'parent_node': app_token,
        'size': str(file_size)
    }
    
    upload_resp = session.post(
        'https://open.feishu.cn/open-apis/drive/v1/medias/upload_all',
        headers={'Authorization': f'Bearer {token}'},
        files=files,
        data=data
    )
    upload_result = upload_resp.json()
    if upload_result.get('code') != 0:
        raise Exception(f"上传失败: {upload_result}")
    
    file_token = upload_result['data']['file_token']
    
    # 步骤2: 更新记录
    update_resp = session.put(
        f'https://open.feishu.cn/open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/records/{record_id}',
        headers={'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'},
        json={'fields': {field_name: [{'file_token': file_token}]}}
    )
    
    return update_resp.json()

if __name__ == '__main__':
    if len(sys.argv) < 6:
        print("Usage: python upload_attachment.py <file_path> <app_token> <table_id> <record_id> <field_name>")
        sys.exit(1)
    
    try:
        result = upload_to_bitable(
            file_path=sys.argv[1],
            app_token=sys.argv[2],
            table_id=sys.argv[3],
            record_id=sys.argv[4],
            field_name=sys.argv[5]
        )
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
